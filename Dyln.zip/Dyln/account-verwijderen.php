<?php
ob_start();
session_start();

include "includes/dbconnect.php";
  ?>

  <?php
    require 'includes/database.php';
    $loginid = 0;
 

    if ( !empty($_GET['loginid'])) {
        $loginid = $_REQUEST['loginid'];
    }

    if ( !empty($_POST)) {
        // keep track post values
        $loginid = $_POST['loginid'];

        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM loginsysteem WHERE loginid = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($loginid));
        Database::disconnect();
        header("Location: accounts.php");
        }
       

?>
<div class="container">

                <div class="span10 offset1">
                    <div class="row">
                        <h3>Verwijder een klant</h3>
                    </div>

                    <form class="form-horizontal" action="account-verwijderen.php" method="post">
                      <input type="hidden" name="loginid" value="<?php echo $loginid;?>"/>
                      <p class="alert alert-error">Weet je het zeker</p>
                      <div class="form-actions">
                          <button type="submit" class="btn btn-danger">Yes</button>
                          <a class="btn" href="accounts.php">No</a>
                        </div>
                    </form>
                </div>

    </div> <!-- /container -->