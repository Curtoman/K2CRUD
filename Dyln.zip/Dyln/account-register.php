<?php

session_start();


include "includes/dbconnect.php";

if (isset($_POST['register'])){
			$naam = ($_POST["naam"]);
			$username = ($_POST["username"]);
			$password = md5($_POST["password"]);
			$usertype = ($_POST["usertype"]);
			

			
	
			$sql2 = "INSERT INTO `loginsysteem`(`username`, `password`, `usertype`) VALUES ('$username', '$password', '$usertype')";			

				
			     mysqli_query ($conn, $sql2);


            header('location:accounts.php');


}
?>
