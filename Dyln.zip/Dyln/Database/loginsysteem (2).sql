-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 14 jun 2021 om 20:34
-- Serverversie: 10.4.14-MariaDB
-- PHP-versie: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `topteamapp`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `loginsysteem`
--

CREATE TABLE `loginsysteem` (
  `loginid` int(11) NOT NULL,
  `username` varchar(24) COLLATE latin1_german1_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_german1_ci NOT NULL,
  `usertype` varchar(11) COLLATE latin1_german1_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

--
-- Gegevens worden geëxporteerd voor tabel `loginsysteem`
--

INSERT INTO `loginsysteem` (`loginid`, `username`, `password`, `usertype`) VALUES
(1, 'ercu', '563033949a8726a56c15db40deed07d9', 'beheerder'),
(13, 'ali', '202cb962ac59075b964b07152d234b70', 'medewerker'),
(14, 'ote', '827ccb0eea8a706c4c34a16891f84e7b', 'medewerker'),
(15, 'test', '202cb962ac59075b964b07152d234b70', 'medewerker'),
(17, 'dylannn', '4f97319b308ed6bd3f0c195c176bbd77', 'beheerder');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `loginsysteem`
--
ALTER TABLE `loginsysteem`
  ADD PRIMARY KEY (`loginid`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `loginsysteem`
--
ALTER TABLE `loginsysteem`
  MODIFY `loginid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
