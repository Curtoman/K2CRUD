<?php

$conn = new mysqli ('localhost','root','','topteamapp');

?>